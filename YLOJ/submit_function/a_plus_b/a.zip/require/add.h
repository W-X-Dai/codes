#ifndef __ADD_H__
#define __ADD_H__

#ifdef __cplusplus
extern "C" {
#endif
	int add(int n_a, int n_b);
#ifdef __cplusplus
}
#endif

#endif