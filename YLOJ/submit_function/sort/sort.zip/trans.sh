for i in {11..20}
do
    #touch "C"$i".in"
    touch "C"$i".out"
done