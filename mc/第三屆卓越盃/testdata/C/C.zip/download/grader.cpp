#include "pc.h"
#include<iostream>
#include<string.h>

static string s;

int main(){
	std::cin >>s;
	std::cout<<sol(s)<<'\n';

	return 0;
}