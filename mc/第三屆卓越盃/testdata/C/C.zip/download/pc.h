#include<bits/stdc++.h>
using namespace std;
#ifndef __PC_H__
#define __PC_H__
#ifdef __cplusplus
extern "C" {
#endif
	string sol(string s);
#ifdef __cplusplus
}
#endif

#endif