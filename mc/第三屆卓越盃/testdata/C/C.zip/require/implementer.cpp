#include "pc.h"
#include<stdio.h>
#include<iostream>
#include<string.h>

static string __s;

int main(){
	std::cin >>__s;

	std::cout<<"joshispooratcoding\n";
	std::cout<<sol(__s)<<'\n';

	return 0;
}