for i in {1..10}
do
    mv $i".in" "A"$i".in"
    mv $i."out" "A"$i".out"
done