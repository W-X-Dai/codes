for i in {6..10}
do
    #mv $i".in" "B"$i".in"
    #mv $i."out" "B"$i".out"
    touch "B"$i".in"
done