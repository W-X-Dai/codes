for i in {1..8}
do
    
    filename="A"`expr $i + 25`
    mv "4-0"$i".in" $filename".in"
    mv "4-0"$i".out" $filename".out"
    echo $filename".out"



done

