score:
plus_00  1%
plus_01 33%
plus_02 33%
plus_03 33%
solve :
a+b.cpp