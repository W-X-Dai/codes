score:
a_00  1%
a_01 33%
a_02 33%
a_03 33%
solve :
pA-2.cpp